import requests

def lambda_handler():
   print('Hello World!')

